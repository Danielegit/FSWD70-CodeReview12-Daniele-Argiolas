
<footer class="blog-footer bg-dark text-white  w-100 h-100 mt-5">
     
     <button class="btn btn-secondary">
       <a href="#" class="text-white">Back to top</a>
     </button>
     <p class="text-center">&copy; <?php echo Date('Y'); ?> <?php bloginfo('name'); ?></p>
   </footer>
   <?php wp_footer(); ?>


   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>
 </body>
</html>