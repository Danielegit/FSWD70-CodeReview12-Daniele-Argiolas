
<?php get_header(); ?>


<div class="row container-fluid ">

    <div class="col-12 blog-main ">

       <div class="container">
      
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                  <h2 class="text-center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
                  <div class="entry  d-flex align-items-center flex-column">
                     <?php the_content(); ?>
                  </div>

               <?php endwhile; endif; ?>
            
  </div>

      </div><!-- /.blog-post -->   


      <div class="col-3">

       

        
      </div>
  </div>
</div>
<?php get_footer(); ?>
