
<?php get_header(); ?>


<div class="row container-fluid d-flex justify-content-center m-0">
  <div class="col-12 w-100" id="back-img">
    
  </div>

    <div class="col-12 blog-main ">

             <?php if(have_posts()) :  ?>  <!--if there are any posts-->
                <?php while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->

              <div class="blog-post m-3 text-center">
               <h2 class="">
                 <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a>
               </h2>
              <p class=""><?php the_content(); ?></p>
               </div>
              <?php endwhile; ?> <!--end the while loop-->

                <?php else : ?> <!--if there are no posts-->
                  <p><?php__('No Posts Found'); ?></p>
               <?php endif; ?><!--endif-->
      </div><!-- /.blog-post -->   

      <h2 class="text-center p-4">Travel with us </h2>
      <div class="col-12 row" id="home_imgs">
        
        <div class="col-lg-6 col-md-6 col-12 p-5">
          <h2>Trekking</h2>
          <p>
            Everest Hiking Service Pvt. Ltd. is a Kathmandu based local trekking, tour, and adventure company. We operate our service in Nepal  Bhutan and Tibet. Our website name is www.hikingeverest.com. The team of Everest Hiking Service are qualified and have enough experience to serve trekking, tours, hiking, and adventure services in Himalayas mountain. 
          </p>
        </div>
        <div class="col-lg-6 col-md-6 col-12 p-2"  >
          <div id="img_one" class="w-100 h-100" >
            
          </div>
        </div>


        <div class="col-lg-6 col-md-6 col-12 p-2"  >
          <div id="img_two" class="w-100 h-100" >
            
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-12 p-5">
          <h2>Experience</h2>
          <p>
            Our experienced trek guides, tour leaders have experience from a different reputed company in the past can provide responsibly and customize service according to customer need. Our mountain climbers have multiple times experience of climbing of high mountains including Mount Everest. 
          </p>
        </div>


        <div class="col-lg-6 col-md-6 col-12 p-5">
          <h2>Enjoy</h2>
          <p>
            Operates some of the best tours and trekking in the world like Everest base camp trek, Annapurna circuit trek, and so on, we want to arrange and show the top destination of the Himalayan region. You can enjoy it at your speed. Thus, we can facilitate to think about what kind of tours
          </p>
        </div>
        <div class="col-lg-6 col-md-6 col-12 p-2"  >
          <div id="img_three" class="w-100 h-100" >
            
          </div>
        </div>
        
        
      </div>
       <div class="col-12 mt-4 p-4">

           <div id="bg_two" class=" w-100 h-100">
             
           </div>
      </div>


      <div class="col-12 mt-4 p-4">
        <h3 class="text-center">About Us</h3>

        <p >
          
            There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.
          
            There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.

        </p>
      </div>

      <div id="last">
        The Director
      </div>
  </div>

<?php get_footer(); ?>