
<?php get_header(); ?>


<div class=" container-fluid ">

 

       <div class="container  d-flex justify-content-center">
          <div class="w-100 p-5">
            
          
               <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                  <h2 class="text-center"><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
                  <div class="entry  d-flex align-items-center flex-column">
                     <?php the_content(); ?>
                  </div>
                  <p class="blog-post-meta text-right"><strong><?php the_time('F j, Y g:i a'); ?>

                    <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></strong></p>


                
               <?php endwhile; endif; ?>
            </div>
         </div>

      </div><!-- /.blog-post -->   


 
</div>




<?php
      /* Start the Loop */
      while ( have_posts() ) :
        the_post();

        get_template_part( 'template-parts/post/content', get_post_format() );

        // If comments are open or we have at least one comment, load up the comment template.
        if ( comments_open() || get_comments_number() ) :
          comments_template();
        endif;

      endwhile; // End of the loop.
      ?>
<?php get_footer(); ?>
