
<?php get_header(); 

if(is_active_sidebar('sidebar')){
  echo '<div class="row container-fluid mt-5 pl-5">
        <div class="col-lg-10 col-md-10 col-12 blog-main p-2 row d-flex justify-content-around">';
}else{
  echo '<div class="row container-fluid mt-5 pl-5">
        <div class=" col-12 blog-main p-2 row d-flex justify-content-around">';
}
?>


             <?php if(have_posts()) :  ?>  <!--if there are any posts-->
                <?php while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->

              <div class="blog-post text-center col-lg-5 m-2  mb-5">
                  <div class="p-3">

                         <h2 class="">
                           <a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a>

                         </h2>
                                
                          <div id="post_img" ><?php the_content(); ?></div>

                          <p class="blog-post-meta"><?php the_time('F j, Y g:i a'); ?>

                          <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></p>

                          
                    </div>
               </div>
              <?php endwhile; ?> <!--end the while loop-->

                <?php else : ?> <!--if there are no posts-->
                  <p><?php__('No Posts Found'); ?></p>
               <?php endif; ?><!--endif-->
      </div><!-- /.blog-post -->   


      <div class="col-lg-2 col-md-2 col-12">
            <?php
                  if(is_active_sidebar('sidebar')):
                 dynamic_sidebar('sidebar');
                 endif;  
            ?>        
      </div>
  </div>
</div>
<?php get_footer(); ?>
